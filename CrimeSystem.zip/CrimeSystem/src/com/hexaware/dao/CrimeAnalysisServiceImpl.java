package com.hexaware.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.*;
import com.hexaware.model.*;
import com.hexaware.util.DBConnection;

public class CrimeAnalysisServiceImpl implements ICrimeAnalysisService {
	 private static Connection conn;

	    public CrimeAnalysisServiceImpl() {
	        conn = DBConnection.getConnection();
	        
	    }

	    @Override
	    // Method to create a new incident
	    public boolean createIncident(Incident incident) {
	        //Parameterized query
	    	String sql = "INSERT INTO Incidents (IncidentType, IncidentDate, Latitude, Longitude, Description, Status, VictimID, SuspectID, OfficerID) " +
	                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
	        // Setting parameters in the PreparedStatement using the Incident object which is number of rows affected
	        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
	            pstmt.setString(1, incident.getIncidentType());
	            pstmt.setDate(2, new java.sql.Date(incident.getIncidentDate().getTime()));
	            pstmt.setDouble(3, incident.getLatitude());
	            pstmt.setDouble(4, incident.getLongitude());
	            pstmt.setString(5, incident.getDescription());
	            pstmt.setString(6, incident.getStatus());
	            pstmt.setObject(7, incident.getVictimID());
	            pstmt.setObject(8, incident.getSuspectID());
	            pstmt.setObject(9, incident.getOfficerID());

	            int rowsInserted = pstmt.executeUpdate();
	            return rowsInserted > 0;

	        } catch (SQLException e) {
	            System.err.println("Incident creation failed (likely due to invalid FK): " + e.getMessage());
	            return false;
	        }
	    }

	    @Override
	    // Method to update the status of an incident
	    public boolean updateIncidentStatus(String status, int incidentId) {
	        String sql = "UPDATE Incidents SET Status = ? WHERE IncidentID = ?";

	        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
	            pstmt.setString(1, status);
	            pstmt.setInt(2, incidentId);
	            int rowsUpdated = pstmt.executeUpdate();
	            return rowsUpdated > 0;
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }

	        return false;
	    }

	    @Override
	    // Method to get incidents in a date range
	    public List<Incident> getIncidentsInDateRange(Date startDate, Date endDate) {
	        List<Incident> incidents = new ArrayList<>();
	        String sql = "SELECT * FROM Incidents WHERE IncidentDate BETWEEN ? AND ?";

	        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
	            pstmt.setDate(1, new java.sql.Date(startDate.getTime()));
	            pstmt.setDate(2, new java.sql.Date(endDate.getTime()));
	            //Result set is temporary buffer area to store data retrieved from table
	            ResultSet rs = pstmt.executeQuery();

	            while (rs.next()) {
	                Incident incident = new Incident(
	                    
	                    rs.getString("IncidentType"),
	                    rs.getDate("IncidentDate"),
	                    rs.getDouble("Latitude"),
	                    rs.getDouble("Longitude"),
	                    rs.getString("Description"),
	                    rs.getString("Status"),
	                    rs.getInt("VictimID"),
	                    rs.getInt("SuspectID"),
	                    rs.getInt("OfficerID")
	                );
	                incidents.add(incident);
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return incidents;
	    }

	    @Override
	 // Method to search incidents by incident type
	    public List<Incident> searchIncidents(String incidentType) {
	        List<Incident> results = new ArrayList<>();
	        String sql = "SELECT * FROM Incidents WHERE IncidentType = ?";

	        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
	            pstmt.setString(1, incidentType);
	            ResultSet rs = pstmt.executeQuery();

	            while (rs.next()) {
	                Incident incident = new Incident(
	                   
	                    rs.getString("IncidentType"),
	                    rs.getDate("IncidentDate"),
	                    rs.getDouble("Latitude"),
	                    rs.getDouble("Longitude"),
	                    rs.getString("Description"),
	                    rs.getString("Status"),
	                    rs.getInt("VictimID"),
	                    rs.getInt("SuspectID"),
	                    rs.getInt("OfficerID")
	                );
	                results.add(incident);
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return results;
	    }

	    @Override
	 // Method to generate an incident report
	    public Report generateIncidentReport(Incident incident) {
	        String sql = "SELECT i.*, o.firstName AS officerName, v.firstName AS victimName, s.firstName AS suspectName " +
	                     "FROM Incidents i " +
	                     "LEFT JOIN Officers o ON i.OfficerID = o.OfficerID " +
	                     "LEFT JOIN Victims v ON i.VictimID = v.VictimID " +
	                     "LEFT JOIN Suspects s ON i.SuspectID = s.SuspectID " +
	                     "WHERE i.IncidentID = ?";

	        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
	            pstmt.setInt(1, incident.getIncidentID());
	            ResultSet rs = pstmt.executeQuery();

	            if (rs.next()) {
	                return new Report(0, incident.getIncidentID(), incident.getOfficerID(),
	                                  new Date(),
	                                  "Report for: " + incident.getIncidentType() +
	                                  " involving officer: " + rs.getString("officerName"),
	                                  incident.getStatus());
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return null;
	    }

	    @Override
	 // Method to add new Reports by User
	    public boolean addIncidentReport(Report report) {
	        String sql = "INSERT INTO Reports (incidentID, reportingOfficer, reportDate, reportDetails, status) " +
	                     "VALUES (?, ?, ?, ?, ?)";

	        try (PreparedStatement ps = conn.prepareStatement(sql)) {
	            ps.setInt(1, report.getIncidentID());
	            ps.setInt(2, report.getReportingOfficer());
	            ps.setDate(3, new java.sql.Date(report.getReportDate().getTime()));
	            ps.setString(4, report.getReportDetails());
	            ps.setString(5, report.getStatus());

	            int rowsInserted = ps.executeUpdate();
	            return rowsInserted > 0;
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }

	        return false;
	    }

	    @Override
	    //Method to add victim by users where victimID is generated automatically.
	    public int addVictim(Victim victim) {
	        String sql = "INSERT INTO Victims (firstName, lastName, dateOfBirth, gender, contactInfo) VALUES (?, ?, ?, ?, ?)";
	        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
	            ps.setString(1, victim.getFirstName());
	            ps.setString(2, victim.getLastName());
	            ps.setDate(3, new java.sql.Date(victim.getDateOfBirth().getTime()));
	            ps.setString(4, victim.getGender());
	            ps.setString(5, victim.getContactInfo());

	            int rowsInserted = ps.executeUpdate();
	            if (rowsInserted > 0) {
	                ResultSet rs = ps.getGeneratedKeys();//To retrieve the keys auto-generated by the database 
	                if (rs.next()) {
	                    return rs.getInt(1); // return generated victim ID
	                }
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return -1; // error
	    }

	    @Override
	  //Method to add suspect by users where suspectID is generated automatically.
	    public int addSuspect(Suspect suspect) {
	        String sql = "INSERT INTO Suspects (firstName, lastName, dateOfBirth, gender, contactInfo) VALUES (?, ?, ?, ?, ?)";
	        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
	            ps.setString(1, suspect.getFirstName());
	            ps.setString(2, suspect.getLastName());
	            ps.setDate(3, new java.sql.Date(suspect.getDateOfBirth().getTime()));
	            ps.setString(4, suspect.getGender());
	            ps.setString(5, suspect.getContactInfo());

	            int rowsInserted = ps.executeUpdate();
	            //To Check if the INSERT statement actually inserted a row
	            if (rowsInserted > 0) {
	                ResultSet rs = ps.getGeneratedKeys();
	                if (rs.next()) {
	                    return rs.getInt(1); // return generated suspect ID
	                }
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return -1; // error
	    }

	    // Method with subquery to get incidents assigned to a specific officer by name
	    public List<Incident> getIncidentsByOfficerName(String officerName) {
	        List<Incident> results = new ArrayList<>();
	        String sql = "SELECT * FROM Incidents WHERE OfficerID IN (SELECT OfficerID FROM Officers WHERE firstName = ?)";

	        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
	            pstmt.setString(1, officerName);
	            ResultSet rs = pstmt.executeQuery();

	            while (rs.next()) {
	                Incident incident = new Incident(
	                    rs.getString("IncidentType"),
	                    rs.getDate("IncidentDate"),
	                    rs.getDouble("Latitude"),
	                    rs.getDouble("Longitude"),
	                    rs.getString("Description"),
	                    rs.getString("Status"),
	                    rs.getInt("VictimID"),
	                    rs.getInt("SuspectID"),
	                    rs.getInt("OfficerID")
	                );
	                results.add(incident);
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return results;
	    }

	    // get incident counts by type
	    public void printIncidentTypeSummary() {
	        String sql = "SELECT IncidentType, COUNT(*) AS total FROM Incidents GROUP BY IncidentType";

	        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
	            ResultSet rs = pstmt.executeQuery();

	            while (rs.next()) {
	                System.out.println("Type: " + rs.getString("IncidentType") + ", Count: " + rs.getInt("total"));
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
}
