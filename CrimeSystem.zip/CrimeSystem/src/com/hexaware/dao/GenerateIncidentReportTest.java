package com.hexaware.dao;

import org.junit.jupiter.api.Test;

import com.hexaware.model.Incident;
import com.hexaware.model.Report;

import static org.junit.jupiter.api.Assertions.*;


public class GenerateIncidentReportTest {
	
	CrimeAnalysisServiceImpl service = new CrimeAnalysisServiceImpl();
	
	@Test
	public void testGenerateIncidentReport() {
	    Incident dummyIncident = new Incident();
	    dummyIncident.setIncidentID(1); // set an existing ID from DB

	    Report report = service.generateIncidentReport(dummyIncident);
	    assertNotNull(report);
	    assertEquals(1, report.getIncidentID());
	}

}
