package com.hexaware.dao;

import com.hexaware.model.Incident;
import com.hexaware.model.Victim;
import com.hexaware.model.Suspect;
import com.hexaware.model.Report;
import java.util.Date;
import java.util.List;

public interface ICrimeAnalysisService {
	
	    // Create a new incident
		boolean createIncident(Incident incident);
		
		// Update the status of an incident
	    boolean updateIncidentStatus(String status, int incidentId);

	    // Get a list of incidents within a date range
	    List<Incident> getIncidentsInDateRange(Date startDate, Date endDate);
	    
	    // Search for incidents based on various criteria
	    List<Incident> searchIncidents(String incidentType);

	    // Generate incident reports
	    Report generateIncidentReport(Incident incident);
    
        // To add new Reports by User
        boolean addIncidentReport(Report report);
        
        //To insert new Victims by User where VictimID is auto-generatd by Database
        public int addVictim(Victim victim) ;
        
      //To insert new Suspects by User where SuspectID is auto-generatd by Database
        public int addSuspect(Suspect suspect);
        
     // Method with subquery to get incidents assigned to a specific officer by name
	    public List<Incident> getIncidentsByOfficerName(String officerName);
        
      //To get incident counts by type
        public void printIncidentTypeSummary();

}
