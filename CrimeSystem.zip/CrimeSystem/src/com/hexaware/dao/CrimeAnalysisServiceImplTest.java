package com.hexaware.dao;

import com.hexaware.model.Incident;
import com.hexaware.model.Suspect;
import com.hexaware.model.Victim;

import org.junit.jupiter.api.Test;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;
public class CrimeAnalysisServiceImplTest {
	
	CrimeAnalysisServiceImpl service = new CrimeAnalysisServiceImpl();

    @Test
    public void testCreateIncidentSuccess() {
    	//To insert Victim using addVictim method and use that victim id for valid test case
        Victim victim = new Victim("Test", "Victim", new Date(), "Male", "1234567890");
        int victimId = service.addVictim(victim);
        assertTrue(victimId > 0, "Victim should be added and return valid ID");
        
      //To insert Victim using addSuspect method and use that suspect id for valid test case
        Suspect suspect = new Suspect("Test", "Suspect", new Date(), "Female", "9876543210");
        int suspectId = service.addSuspect(suspect);
        assertTrue(suspectId > 0, "Suspect should be added and return valid ID");

        int officerId = 3; //already existing officerID  

        Incident incident = new Incident("Robbery", new Date(), 12.34, 56.78, "Cash robbery in street", "Open", victimId, suspectId, officerId);
        boolean result = service.createIncident(incident);
        System.out.println("Test result for valid data: " + result);

        assertTrue(result, "Incident should be created successfully");
    }
    @Test
    // Testing with invalid victimID
    public void testCreateIncidentWithInvalidVictimId() {
        Incident incident = new Incident("Theft", new Date(), 12.34, 56.78, "Bike theft", "Closed", 999, 2, 3); // victimID=999 is invalid
        boolean result = service.createIncident(incident);
        System.out.println("Test result for invalid victim ID: " + result);

        assertFalse(result, "Incident creation should fail due to invalid VictimID");
    }
}
