package com.hexaware.dao;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
public class UpdateIncidentStatusTest {
	
	CrimeAnalysisServiceImpl service = new CrimeAnalysisServiceImpl();
	
	public void testUpdateIncidentStatus_Success() {
	    
		boolean result = service.updateIncidentStatus("Closed", 1); // incidentID 1 exists
	    assertTrue(result, "Incident status should be updated successfully");
	}

	@Test
	public void testUpdateIncidentStatus_InvalidIncidentId() {
	    boolean result = service.updateIncidentStatus("Closed", 9999);//invalid incidentID to test
	    assertFalse(result, "Update should fail for invalid incident ID");
	}
}
	
	


