package com.hexaware.dao;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import com.hexaware.model.Incident;

public class SearchIncidentsByTypeTest {
	CrimeAnalysisServiceImpl service = new CrimeAnalysisServiceImpl();
	
	@Test
	public void testSearchIncidentsByType_Valid() {
	    List<Incident> results = service.searchIncidents("Robbery");//Already existing incidentType
	    assertNotNull(results);
	    assertTrue(results.size() >= 0);
	}

	@Test
	public void testSearchIncidentsByType_InvalidType() {
	    List<Incident> results = service.searchIncidents("AlienAbduction");//Tested with non-existing incidentType
	    assertNotNull(results);
	    assertEquals(0, results.size(), "Should return no incidents for unknown type");
	}

}
