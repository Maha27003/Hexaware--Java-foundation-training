package com.hexaware.dao;

import org.junit.jupiter.api.Test;



import static org.junit.jupiter.api.Assertions.*;

public class IncidentStatusUpdateTest {
	
	CrimeAnalysisServiceImpl service = new CrimeAnalysisServiceImpl();

    @Test
    public void testUpdateStatusSuccess() {
        boolean result = service.updateIncidentStatus("Closed", 1); // incident ID 1 exists
        System.out.println("Test result for invalid ID: "+result);
        assertTrue(result, "Incident status should be updated successfully");
    }

    @Test
    //Testing with invalid incidentID
    public void testUpdateStatusInvalidIncidentId() {
        boolean result = service.updateIncidentStatus("Closed", 9999); // Non-existent incident
        System.out.println("Test result for invalid ID: "+result);
        assertFalse(result, "Status update should fail for invalid incident ID");
    }

}
