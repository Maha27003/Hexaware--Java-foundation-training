package com.hexaware.main;

import com.hexaware.model.*;
import com.hexaware.dao.CrimeAnalysisServiceImpl;
import com.hexaware.myexceptions.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainModule {
	
	public static void main(String[] args) {
        CrimeAnalysisServiceImpl service = new CrimeAnalysisServiceImpl();
        Scanner sc = new Scanner(System.in);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

        int choice = 0;

        do {
            System.out.println("\n--- Crime Analysis and Reporting System ---");
            System.out.println("1. Create a new Incident");
            System.out.println("2. Update Incident Status");
            System.out.println("3. Get Incidents in Date Range");
            System.out.println("4. Search Incidents by Type");
            System.out.println("5. Generate Incident Report");
            System.out.println("6. Add Incident Report");
            System.out.println("7. Add New Victim");
            System.out.println("8. Add New Suspect");
            System.out.println("9. Search Incidents by Officer Name");
            System.out.println("10. Incident Type Summary");
            System.out.println("11. Exit");
            System.out.print("Enter your choice: ");

            choice = sc.nextInt();
            sc.nextLine();

            try {
                switch (choice) {
                    case 1:
                        // To get input from user to create a incident
                        System.out.print("Enter Incident Type: ");
                        String type = sc.nextLine();
                        System.out.print("Enter Description: ");
                        String desc = sc.nextLine();
                        System.out.print("Enter Date (yyyy-MM-dd): ");
                        Date date = sdf.parse(sc.nextLine());
                        System.out.print("Enter Latitude: ");
                        double lat = sc.nextDouble();
                        System.out.print("Enter Longitude: ");
                        double lon = sc.nextDouble();
                        sc.nextLine();
                        System.out.print("Enter Status: ");
                        String status = sc.nextLine();
                        System.out.print("Enter Victim ID (or 0 for NULL): ");
                        int vicId = sc.nextInt();
                        System.out.print("Enter Suspect ID (or 0 for NULL): ");
                        int susId = sc.nextInt();
                        System.out.print("Enter Officer ID: ");
                        int offId = sc.nextInt();
                        sc.nextLine();

                        Incident incident = new Incident(type, date, lat, lon, desc, status,
                                vicId == 0 ? null : vicId, susId == 0 ? null : susId, offId);
                        if (service.createIncident(incident)) {
                            System.out.println("Incident created successfully.");
                        } else {
                            System.out.println("Failed to create incident.");
                        }
                        break;

                    case 2:
                    	//Updating incident status using incidentID
                        System.out.print("Enter Incident ID to update: ");
                        int incId = sc.nextInt();
                        sc.nextLine();
                        System.out.print("Enter new status: ");
                        String newStatus = sc.nextLine();
                        if (!service.updateIncidentStatus(newStatus, incId)) {
                            //custom exception is thrown when incidentiD is not found
                        	throw new IncidentNumberNotFoundException("Incident ID not found: " + incId);
                        } else {
                            System.out.println("Incident status updated.");
                        }
                        break;

                    case 3:
                    	//To get incidents occurred between given date range
                        System.out.print("Enter Start Date (yyyy-MM-dd): ");
                        Date start = sdf.parse(sc.nextLine());
                        System.out.print("Enter End Date (yyyy-MM-dd): ");
                        Date end = sdf.parse(sc.nextLine());
                        List<Incident> rangeIncidents = service.getIncidentsInDateRange(start, end);
                        if (rangeIncidents.isEmpty()) {
                            throw new InvalidDateRangeException("No incidents found in date range");
                        }
                        rangeIncidents.forEach(System.out::println);
                        break;

                    case 4:
                    	//To incident of specific incident type
                        System.out.print("Enter Incident Type to search: ");
                        String incidentType = sc.nextLine();
                        List<Incident> found = service.searchIncidents(incidentType);
                        if (found.isEmpty()) {
                            throw new InvalidIncidentTypeException("No incidents found of type: " + incidentType);
                        }
                        found.forEach(System.out::println);
                        break;

                    case 5:
                    	//To get report for specific incident using its incident id
                        System.out.print("Enter Incident ID to generate report: ");
                        int reportId = sc.nextInt();
                        sc.nextLine();
                        Incident reportIncident = new Incident();
                        reportIncident.setIncidentID(reportId);
                        Report rep = service.generateIncidentReport(reportIncident);
                        System.out.println(rep);
                        break;

                    case 6:
                    	//To add report for incident
                        System.out.print("Enter Incident ID: ");
                        int iid = sc.nextInt();
                        System.out.print("Enter Reporting Officer ID: ");
                        int roffid = sc.nextInt();
                        sc.nextLine();
                        System.out.print("Enter Report Details: ");
                        String details = sc.nextLine();
                        System.out.print("Enter Report Status: ");
                        String rstatus = sc.nextLine();
                        Date now = new Date();
                        Report report = new Report(0, iid, roffid, now, details, rstatus);
                        System.out.println(service.addIncidentReport(report) ? "Report added." : "Failed to add.");
                        break;

                    case 7:
                    	// To add new Victim
                        System.out.print("First Name: ");
                        String vf = sc.nextLine();
                        System.out.print("Last Name: ");
                        String vl = sc.nextLine();
                        System.out.print("DOB (yyyy-MM-dd): ");
                        Date vdob = sdf.parse(sc.nextLine());
                        System.out.print("Gender: ");
                        String vg = sc.nextLine();
                        System.out.print("Contact: ");
                        String vc = sc.nextLine();
                        Victim victim = new Victim(vf, vl, vdob, vg, vc);
                        int victimId = service.addVictim(victim);
                        if (victimId == -1) throw new VictimNotFoundException("Could not insert victim.");
                        System.out.println("Victim added with ID: " + victimId);
                        break;

                    case 8:
                    	//To add new suspect
                        System.out.print("First Name: ");
                        String sf = sc.nextLine();
                        System.out.print("Last Name: ");
                        String sl = sc.nextLine();
                        System.out.print("DOB (yyyy-MM-dd): ");
                        Date sdob = sdf.parse(sc.nextLine());
                        System.out.print("Gender: ");
                        String sg = sc.nextLine();
                        System.out.print("Contact: ");
                        String scinfo = sc.nextLine();
                        Suspect suspect = new Suspect(sf, sl, sdob, sg, scinfo);
                        int suspectId = service.addSuspect(suspect);
                        System.out.println("Suspect added with ID: " + suspectId);
                        break;

                    case 9:
                    	//Get a incident using their reporting officer 
                        System.out.print("Enter Officer Name: ");
                        String officerName = sc.nextLine();
                        List<Incident> list = service.getIncidentsByOfficerName(officerName);
                        list.forEach(System.out::println);
                        break;

                    case 10:
                    	//Generates count of incidents reported for specific incident type
                        service.printIncidentTypeSummary();
                        break;

                    case 11:
                        System.out.println("Exiting...");
                        break;

                    default:
                        System.out.println("Invalid choice. Try again.");
                }

            } catch (InvalidDateRangeException | InvalidIncidentTypeException | IncidentNumberNotFoundException  | VictimNotFoundException e) {
                System.err.println("Custom Error: " + e.getMessage());
            } catch (Exception e) {
                System.err.println("Error: " + e.getMessage());
            }

        } while (choice != 11);

        sc.close();
    }
}
