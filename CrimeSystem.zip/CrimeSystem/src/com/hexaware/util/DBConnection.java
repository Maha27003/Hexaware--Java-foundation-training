package com.hexaware.util;

import java.sql.Connection;

import java.sql.DriverManager;


public class DBConnection {
	
	public static Connection connection = null;
	 
	public DBConnection() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public static Connection getConnection()
	{
		//singleton design pattern
		if (connection == null)
		{
			try
			{
				
				
				connection = DriverManager.getConnection(
													PropertyUtil.get("url"),
													PropertyUtil.get("username"),
													
													PropertyUtil.get("password")
						);
				
			}
		catch(Exception  e)
		{
			e.printStackTrace();
		}
		}
		return connection;
	}
}
