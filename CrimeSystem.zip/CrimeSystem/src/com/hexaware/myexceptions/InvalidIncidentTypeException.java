package com.hexaware.myexceptions;

public class InvalidIncidentTypeException extends Exception {
	
	private static final long serialVersionUID = 1L;

	public InvalidIncidentTypeException(String message) {
        super(message);
    }

}
