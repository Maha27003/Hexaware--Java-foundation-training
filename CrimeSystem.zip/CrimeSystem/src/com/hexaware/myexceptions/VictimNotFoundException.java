package com.hexaware.myexceptions;

//Thrown when a victim ID does not exist in the database
public class VictimNotFoundException extends Exception{
	
	 private static final long serialVersionUID = 4L;

	    public VictimNotFoundException() {
	        super("Victim ID not found.");
	    }

	    public VictimNotFoundException(String message) {
	        super(message);
	    }

}
